
Contents of the ZIP
-------------------------
The zip package contains two files deploy.sh & template.json.  Extract the  zip to a ubuntu linux server with bash.
 
Prerequisites: 
------------- 
Install Azure CLI 2.0 prior to executing the script.  Login to the Azure subscription using 'az login' and not the subscription details for running the deploy script. 

What Does it do?
----------------
The script deploys Azure VMs to multiple resource groups with each resource group having one deployment with 
       - One VNET with one Subnet
       - VMs ranging from 2 to 400
       - Associates VMs with precreated NICs/PublicIPs
The script makes use of ARM template "template.json" for the details of resources for each resource group. The script deploys VMs & other resources with names/prefixes as per template.json.
The script will launch VMs in a loop if the number of VMs are more than 100.  This is to take care of the limits on Azure Resource Group and Azure Availability SET.  The script computes the number of RGs required based on the #VMs to be deployed.

Configuration:
--------------
deploy.sh can be configured to deploy a minimum of 2 instances and a maximum of 100 instances per resource group.  Hence, it should be used to deploy minimally 2 or more  Azure VMs. The script will fail if it is used to deploy single instance.
The maximum number instances per resource group is set to 100 as default value and  can be changed by changing the value for  the variable "instancesPerRG" in the script (line#6)
The script can be used to deploy either Ubuntu or Windows VMs on Azure.  This can be configured by changing the "OS" variable in the script deploy.sh. (line#6)

Usage:
------
deploy.sh  -i <subscriptionId> -g <resourceGroupName> -n <deploymentName> -l <resourceGroupLocation> -o <numberOfInstances> -p <adminUserName> -c <RGofNICS>
options:
-i  - SubscriptionID into which the instances are to be deployed
-g  - ResourceGroupName to deploy the instances.  if more than one RG is required 
      based on number of instances, additional resourcegroups will created with names 
      appended with 0,1,2,...etc.
-n  - Name of the deployment within the ResourceGroup.  If more than one RG is 
      created, deployment name also appended with 0,1,2...etc. based on no. of 
      deployments. 
-l  - resourceGroupLocation is the Azure region where the resources are to be    
      deployed. Valid names for Azure regions are listed here
-o  - Number of instances to be deployed for which the minimum is 2 and maximum can be 
      any even number upto to subscription limit for number of VMs
-p  - user name for administrator on the instances to deploy.
-c  - Resource Group prefix where the NICs are created

Example: 
-------
#deploy.sh -i xxxxxx-36b1-4eef-b8f3-ec8a539d10ea -g exampleRG -n exdeployID -l eastus -o 210 -p adminuser
Upon validation of options, the script will prompt for password which will set as password for admin user on each of the VM deployed.
While deploying instances into multiple ResourceGroups, the script will create parametrs.json* files for each deployment to pass the values of parameters in the template to the Azure Resource manager. 

Example Deployment output: 
-------------------------
For the above example, the script will validate the inputs and deploy the following which can be checked in the portal:
exampleRG0:  myvm0 ...myvm99 (with associated resources nic0..nic99, publicip0.. publicip99) 
exampleRG1:  myvm100..myvm199 (with associated resources nic100..nic199, publicip100..publicip199)
exampleRG2:  myvm200.. myvm209 (with associated resources nic200..nic209, publicip200..publicip209)



