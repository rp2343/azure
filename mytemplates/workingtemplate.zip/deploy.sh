#bin/bash

set -euo pipefail

instancesPerRG=40
OS="Ubuntu"

createParametersFile()
{
outFile="$1"
adminUserName="$2"
adminPassword="$3"
OS="$4"
Instances=$5
resourcePrefix=$6
nicRg=$7
echo "{" >> $outFile
echo "   \"\$scchema\": \"https://schema.management.azure.com/schemas/2015-01-01/deploymentParameters.json#\"," >>$outFile
echo " \"contentVersion\": \"1.0.0.0\", " >>$outFile
echo " \"parameters\": { " >>$outFile
echo "          \"adminUsername\": {" >>$outFile
echo "          \"value\": \"$adminUserName\" " >> $outFile
echo "         }," >> $outFile
echo "         \"adminPassword\": { " >>$outFile
echo "         \"value\": \"$adminPassword\"" >>$outFile
echo "         }," >> $outFile
echo "         \"OS\": {" >>$outFile
echo "         \"value\" : \"$OS\"" >>$outFile
echo "         }," >> $outFile
echo "         \"nicRg\": { " >> $outFile
echo "         \"value\": \"$nicRg\"" >>$outFile
echo "         }," >>$outFile
echo "         \"numberOfInstances\": { " >> $outFile
echo "         \"value\": $Instances" >>$outFile
echo "         }," >>$outFile
echo "         \"resourcePrefix\": { " >> $outFile
echo "         \"value\": $resourcePrefix" >>$outFile
echo "        }" >>$outFile
echo "      }" >> $outFile
echo "}">>$outFile
}


usage() { echo "Usage: $0 -i <subscriptionId> -g <resourceGroupName> -n <deploymentName> -l <resourceGroupLocation> -c <RGofNICs>-o <numberOfInstances> -p <adminUserName>  " 1>&2; exit 1; }

declare subscriptionId=""
declare resourceGroupName=""
declare deploymentName=""
declare resourceGroupLocation=""
declare numberOfInstances=0
declare adminUserName=""
declare nicRg=""

# Initialize parameters specified from command line
while getopts ":i:g:n:l:o:p:c:" arg; do
        case "${arg}" in
                i)
                        subscriptionId=${OPTARG}
                        ;;
                g)
                        resourceGroupName=${OPTARG}
                        ;;
                n)
                        deploymentName=${OPTARG}
                        ;;
                l)
                        resourceGroupLocation=${OPTARG}
                        ;;
                o)
                        numberOfInstances=${OPTARG}
                        ;;
                p)
                        adminUserName=${OPTARG}
                        ;;
	        c)   
                        nicRg=${OPTARG}
                        ;;
                esac
done
shift $((OPTIND-1))

#Prompt for parameters is some required parameters are missing
if [[ -z "$subscriptionId" ]]; then
        echo "Subscription Id:"
        read subscriptionId
        [[ "${subscriptionId:?}" ]]
fi

if [[ -z "$resourceGroupName" ]]; then
        echo "ResourceGroupName:"
        read resourceGroupName
        [[ "${resourceGroupName:?}" ]]
fi
if [[ -z "$deploymentName" ]]; then
        echo "DeploymentName:"
        read deploymentName
fi

if [[  $numberOfInstances == 0 ]]; then
        echo "number of Instances:"
        read numberOfInstances
fi
if [[  -z "$nicRg" ]]; then
        echo "Enter RG name where NICs are deployed:"
        read nicRg
fi

if [[ -z "$adminUserName" ]]; then
        echo "Admin User Name:"
        read adminUserName
fi
# Read the password for Admin user
    echo "Admin User password:"
        read -s adminPassword

if [[ -z "$resourceGroupLocation" ]]; then
        echo "Enter ResourceGroup Location:"
        read resourceGroupLocation
fi
#templateFile Path - template file to be used
templateFilePath="vm-os.json"

if [ ! -f "$templateFilePath" ]; then
        echo "$templateFilePath not found"
        exit 1
fi

if [ -z "$subscriptionId" ] || [ -z "$resourceGroupName" ] || [ -z "$deploymentName" ]; then
        echo "Either one of subscriptionId, resourceGroupName, deploymentName is empty"
        usage
fi

#setarameter file path

parametersFile="parameters.json"
parametersFilePath="@$parametersFile"

#login to azure using your credentials
az account set --subscription $subscriptionId
set +e
# Create RG & Deployment in a loop with each RG having maximum of 100 instances
LoopCount=`expr $numberOfInstances / $instancesPerRG + 1`
echo "This deployment requires $LoopCount resourcegroups"

#Create multiple RGs & Deployments in a loope if #instances are more than the instancesPerRG

instancesToDeploy=0
count=0
resPrefix=0

while [[ $numberOfInstances > 0 ]];
do
echo "Entering deployment loop $LoopCount"

#Check for the last iteration of loop to deploy remaining instances
       if [[ $numberOfInstances > $instancesPerRG ]]; then
                LoopRG="$resourceGroupName$count"
                LoopDeployment="$deploymentName$count"
                instancesToDeploy=$instancesPerRG
        else

                LoopRG="$resourceGroupName$count"
                LoopDeployment="$deploymentName$count"
                instancesToDeploy=$numberOfInstances
        fi

#Check for existing RG
        az group show --name $LoopRG | grep $LoopRG 1> errors.out
        if [ $? != 0 ]; then
        echo "Resource group with name" $LoopRG "could not be found. Creating new resource group.."
#        set -e
        (
                set -x
                az group create --name $LoopRG --location $resourceGroupLocation 1> errors.out
                if [ $? != 0 ];
                then
                        echo "Unable to create Resource Group : $resourceGroupName"
                fi

        )
        else
                echo "Using existing resource group..."
        fi

# Create parameters.json file with inputs provided

        mv $parametersFile "$parametersFile.$LoopCount" 1> errors.out

        createParametersFile "$parametersFile" "$adminUserName" "$adminPassword" "$OS" "$instancesToDeploy" "$resPrefix" "$nicRg" 1> errors.out

#Start deployment
        echo "Starting deployment..."

        set -x
        (
        az group deployment create --name $LoopDeployment --resource-group $LoopRG --template-file $templateFilePath --parameters $parametersFilePath
        )
        if [ $?  == 0 ]; then
                echo "$LoopRG has been successfully deployed"
                resPrefix=`expr $resPrefix + $instancesToDeploy`
                count=`expr $count + 1`
                numberOfInstances=`expr $numberOfInstances - $instancesToDeploy`
                echo $numberOfInstances $instancesToDeploy $resPrefix
        else
                echo "$LoopRG failed to deploy"
        fi
done
